#!/bin/sh
printf '\033c\033]0;%s\a' Taco Clicker
base_path="$(dirname "$(realpath "$0")")"
"$base_path/Taco Clicker.x86_64" "$@"
